<?php exit; ?>
1325871953
SELECT forum_id, forum_name, parent_id, forum_type, forum_flags, forum_options, left_id, right_id FROM phpbb_forums ORDER BY left_id ASC
502
a:2:{i:0;a:8:{s:8:"forum_id";s:1:"1";s:10:"forum_name";s:42:"หมวดหมู่ทั่วไป";s:9:"parent_id";s:1:"0";s:10:"forum_type";s:1:"0";s:11:"forum_flags";s:2:"32";s:13:"forum_options";s:1:"0";s:7:"left_id";s:1:"1";s:8:"right_id";s:1:"4";}i:1;a:8:{s:8:"forum_id";s:1:"2";s:10:"forum_name";s:32:"บอร์ดทดสอบ 1";s:9:"parent_id";s:1:"1";s:10:"forum_type";s:1:"1";s:11:"forum_flags";s:2:"48";s:13:"forum_options";s:1:"0";s:7:"left_id";s:1:"2";s:8:"right_id";s:1:"3";}}